//
//  JSON.h
//  SBJson
//
//  Created by Stig Brautaset on 01/06/2011.
//  Copyright 2011 Stig Brautaset. All rights reserved.
//

#warning The JSON.h header is deprecated, and will disappear in a future release. Please change to include SBJson.h instead.
#include "SBJson.h"