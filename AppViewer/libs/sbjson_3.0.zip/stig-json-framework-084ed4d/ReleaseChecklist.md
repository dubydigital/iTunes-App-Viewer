* Update Changes.md
* % agvtool new-marketing-version XXX
* % agvtool bump
* Update website
* Refresh API documentation
* Close fixed tickets
